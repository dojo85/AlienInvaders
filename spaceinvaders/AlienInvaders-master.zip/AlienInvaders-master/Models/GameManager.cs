﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BlazorWASMTestApp1.Pages.Game;

namespace BlazorWASMTestApp1.Models
{
    public class GameManager
    {
        public ShipModel Ship { get; set; }
        public List<ShotModel> Bullets { get; set; }

        public int ShotsFired { get; set; }

        public event EventHandler GameLoopCompleted;

        public AlienModel Alien { get; set; }
        
        public bool IsRunning { get; set; }

        public GameManager()
        {
            Ship = new ShipModel();
            Bullets = new List<ShotModel>();

            Alien = new AlienModel(60, 30, Bullets);

            IsRunning = true;
            GameLoop();
        }


        public async Task GameLoop()
        {
            while (IsRunning)
            {
                MoveObjects();
                CheckForBulletOutOfRange();
                
                GameLoopCompleted?.Invoke(this, EventArgs.Empty);
                await Task.Delay(20);

            }
        }

        public void MoveObjects()
        {
            foreach (var bullet in Bullets)
            {
                bullet.Fly();
            }
        }

        public async Task GenerateNewShot()
        {
            if (Ship.IsReadyToFire)
            {
                var bullet = await Ship.Shoot();
                Bullets.Add(bullet);
                ShotsFired++;
            }
        }

        private void CheckForBulletOutOfRange()
        {
            foreach (var bullet in Bullets)
            {
                if (bullet.DistanceFromTop <= -20)
                {
                    Bullets.Remove(bullet);
                    break;
                }
            }
        }

    }
}
